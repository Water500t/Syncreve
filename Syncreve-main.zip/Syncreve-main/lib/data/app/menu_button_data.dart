import 'package:flutter/widgets.dart';

class MenuButtonData {
  String actionKey;
  String name;
  IconData icon;

  MenuButtonData(this.actionKey, this.name, this.icon);
}
