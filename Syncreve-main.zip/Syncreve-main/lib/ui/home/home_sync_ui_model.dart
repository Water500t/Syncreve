import 'package:syncreve/base/ui_model.dart';
import 'package:syncreve/ui/home_ui_model.dart';

class HomeSyncUIModel extends BaseUIModel {
  final HomeUIModel homeUIModel;

  HomeSyncUIModel({required this.homeUIModel});
}