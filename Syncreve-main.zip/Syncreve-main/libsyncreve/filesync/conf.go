package filesync

var MaxWorkingTaskNumber int64 = 5
